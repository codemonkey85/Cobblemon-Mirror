"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var formats_data_exports = {};
__export(formats_data_exports, {
  FormatsData: () => FormatsData
});
module.exports = __toCommonJS(formats_data_exports);
const FormatsData = {
  bulbasaur: {
    tier: "LC"
  },
  ivysaur: {
    tier: "NFE"
  },
  venusaur: {
    tier: "NU"
  },
  charmander: {
    tier: "LC"
  },
  charmeleon: {
    tier: "NFE"
  },
  charizard: {
    tier: "NU"
  },
  squirtle: {
    tier: "LC"
  },
  wartortle: {
    tier: "NFE"
  },
  blastoise: {
    tier: "NU"
  },
  caterpie: {
    tier: "LC"
  },
  metapod: {
    tier: "NFE"
  },
  butterfree: {
    tier: "ZU"
  },
  weedle: {
    tier: "LC"
  },
  kakuna: {
    tier: "NFE"
  },
  beedrill: {
    tier: "ZU"
  },
  pidgey: {
    tier: "LC"
  },
  pidgeotto: {
    tier: "NFE"
  },
  pidgeot: {
    tier: "ZU"
  },
  rattata: {
    tier: "LC"
  },
  raticate: {
    tier: "NU"
  },
  spearow: {
    tier: "LC"
  },
  fearow: {
    tier: "PU"
  },
  ekans: {
    tier: "LC"
  },
  arbok: {
    tier: "ZU"
  },
  pikachu: {
    tier: "LC"
  },
  raichu: {
    tier: "UU"
  },
  sandshrew: {
    tier: "LC"
  },
  sandslash: {
    tier: "ZU"
  },
  nidoranf: {
    tier: "LC"
  },
  nidorina: {
    tier: "NFE"
  },
  nidoqueen: {
    tier: "PU"
  },
  nidoranm: {
    tier: "LC"
  },
  nidorino: {
    tier: "NFE"
  },
  nidoking: {
    tier: "NU"
  },
  clefairy: {
    tier: "LC"
  },
  clefable: {
    tier: "UU"
  },
  vulpix: {
    tier: "LC"
  },
  ninetales: {
    tier: "UU"
  },
  jigglypuff: {
    tier: "LC"
  },
  wigglytuff: {
    tier: "NU"
  },
  zubat: {
    tier: "LC"
  },
  golbat: {
    tier: "ZU"
  },
  oddish: {
    tier: "LC"
  },
  gloom: {
    tier: "NFE"
  },
  vileplume: {
    tier: "PU"
  },
  paras: {
    tier: "LC"
  },
  parasect: {
    tier: "ZU"
  },
  venonat: {
    tier: "LC"
  },
  venomoth: {
    tier: "NU"
  },
  diglett: {
    tier: "LC"
  },
  dugtrio: {
    tier: "UU"
  },
  meowth: {
    tier: "LC"
  },
  persian: {
    tier: "UU"
  },
  psyduck: {
    tier: "LC"
  },
  golduck: {
    tier: "NU"
  },
  mankey: {
    tier: "LC"
  },
  primeape: {
    tier: "ZU"
  },
  growlithe: {
    tier: "LC"
  },
  arcanine: {
    tier: "PU"
  },
  poliwag: {
    tier: "ZU"
  },
  poliwhirl: {
    tier: "NU"
  },
  poliwrath: {
    tier: "NU"
  },
  abra: {
    tier: "ZU"
  },
  kadabra: {
    tier: "UU"
  },
  alakazam: {
    tier: "OU"
  },
  machop: {
    tier: "LC"
  },
  machoke: {
    tier: "NFE"
  },
  machamp: {
    tier: "PU"
  },
  bellsprout: {
    tier: "LC"
  },
  weepinbell: {
    tier: "NFE"
  },
  victreebel: {
    tier: "NU"
  },
  tentacool: {
    tier: "LC"
  },
  tentacruel: {
    tier: "UU"
  },
  geodude: {
    tier: "LC"
  },
  graveler: {
    tier: "PU"
  },
  golem: {
    tier: "UU"
  },
  ponyta: {
    tier: "LC"
  },
  rapidash: {
    tier: "PU"
  },
  slowpoke: {
    tier: "ZU"
  },
  slowbro: {
    tier: "OU"
  },
  magnemite: {
    tier: "LC"
  },
  magneton: {
    tier: "ZU"
  },
  farfetchd: {
    tier: "ZU"
  },
  doduo: {
    tier: "LC"
  },
  dodrio: {
    tier: "UU"
  },
  seel: {
    tier: "LC"
  },
  dewgong: {
    tier: "UU"
  },
  grimer: {
    tier: "LC"
  },
  muk: {
    tier: "ZU"
  },
  shellder: {
    tier: "LC"
  },
  cloyster: {
    tier: "OU"
  },
  gastly: {
    tier: "PU"
  },
  haunter: {
    tier: "UU"
  },
  gengar: {
    tier: "OU"
  },
  onix: {
    tier: "ZU"
  },
  drowzee: {
    tier: "PU"
  },
  hypno: {
    tier: "UUBL"
  },
  krabby: {
    tier: "LC"
  },
  kingler: {
    tier: "NU"
  },
  voltorb: {
    tier: "LC"
  },
  electrode: {
    tier: "UU"
  },
  exeggcute: {
    tier: "NU"
  },
  exeggutor: {
    tier: "OU"
  },
  cubone: {
    tier: "LC"
  },
  marowak: {
    tier: "ZU"
  },
  hitmonlee: {
    tier: "ZU"
  },
  hitmonchan: {
    tier: "ZU"
  },
  lickitung: {
    tier: "ZU"
  },
  koffing: {
    tier: "LC"
  },
  weezing: {
    tier: "ZU"
  },
  rhyhorn: {
    tier: "LC"
  },
  rhydon: {
    tier: "OU"
  },
  chansey: {
    tier: "OU"
  },
  tangela: {
    tier: "UU"
  },
  kangaskhan: {
    tier: "UU"
  },
  horsea: {
    tier: "LC"
  },
  seadra: {
    tier: "NU"
  },
  goldeen: {
    tier: "LC"
  },
  seaking: {
    tier: "PU"
  },
  staryu: {
    tier: "PU"
  },
  starmie: {
    tier: "OU"
  },
  mrmime: {
    tier: "NU"
  },
  scyther: {
    tier: "PU"
  },
  jynx: {
    tier: "OU"
  },
  electabuzz: {
    tier: "UU"
  },
  magmar: {
    tier: "PU"
  },
  pinsir: {
    tier: "PU"
  },
  tauros: {
    tier: "OU"
  },
  magikarp: {
    tier: "LC"
  },
  gyarados: {
    tier: "UU"
  },
  lapras: {
    tier: "UUBL"
  },
  ditto: {
    tier: "ZU"
  },
  eevee: {
    tier: "LC"
  },
  vaporeon: {
    tier: "UU"
  },
  jolteon: {
    tier: "OU"
  },
  flareon: {
    tier: "ZU"
  },
  porygon: {
    tier: "PU"
  },
  omanyte: {
    tier: "PU"
  },
  omastar: {
    tier: "UU"
  },
  kabuto: {
    tier: "LC"
  },
  kabutops: {
    tier: "NU"
  },
  aerodactyl: {
    tier: "NU"
  },
  snorlax: {
    tier: "OU"
  },
  articuno: {
    tier: "UU"
  },
  zapdos: {
    tier: "OU"
  },
  moltres: {
    tier: "NU"
  },
  dratini: {
    tier: "LC"
  },
  dragonair: {
    tier: "PU"
  },
  dragonite: {
    tier: "UU"
  },
  mewtwo: {
    tier: "Uber"
  },
  mew: {
    tier: "Uber"
  },
  missingno: {
    isNonstandard: "Unobtainable",
    tier: "Illegal"
  }
};
//# sourceMappingURL=formats-data.js.map
